PUT YOUR PHOTOS HERE (all optional)
-----------------------------------
  momna.jpg     her portrait, shown on the final gallery / end card
  memory1.jpg   a memory photo (caption set in config.js)
  memory2.jpg
  memory3.jpg

If a file is missing the game shows a soft placeholder frame, or nothing at all
if there are no photos. Change names or captions in config.js.
Tip: portrait photos around 800 x 1000 px keep the page light on phones.
