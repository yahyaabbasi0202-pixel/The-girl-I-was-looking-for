PUT YOUR MUSIC HERE
-------------------
Drop your own tracks in this folder using these exact file names:

  day.mp3        school / bus / everyday scenes
  emotional.mp3  missing her, rain, waiting
  mystery.mp3    the wrong account, the clues
  hopeful.mp3    families, friendship, good news
  final.mp3      the last scene

Different format or name? Change the paths in config.js (music.tracks).
Tracks loop and crossfade automatically. If a file is missing, the game plays
a soft built-in ambient tone instead (generated live, nothing copyrighted).
Only use music you have the rights to use if you publish the site publicly.
