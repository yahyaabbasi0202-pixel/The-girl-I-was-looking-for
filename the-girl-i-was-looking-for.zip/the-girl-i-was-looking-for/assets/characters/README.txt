CUSTOM CHARACTER ART (optional)
-------------------------------
The characters are drawn in code, so nothing is needed here.
If you want portraits in the dialogue box, add square images named after the
character key (e.g. yahya.png, momna.png, momnaFriend.png) and see config.js.
